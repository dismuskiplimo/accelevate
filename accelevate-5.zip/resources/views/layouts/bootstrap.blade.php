@include('includes.bootstrap.header')
@include('includes.bootstrap.messages')
@yield('content')
@include('includes.bootstrap.footer')