@extends('layouts.agency')

@section('content')
	<div class="container">
		
			<div class="row my-50 h-400">
        
        
        <div class="col-sm-8">
          <h4>Privacy Policy</h4>

        </div>
            
        
      </div>
			
		
	</div>

	
@endsection