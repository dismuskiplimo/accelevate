<!doctype html>
<html>
	<head>
		<title></title>
		<meta charset = "utf-8">
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		
		@include('includes.email.bootstrap')
		@include('includes.email.styles')
		
	</head>
	<body>
		