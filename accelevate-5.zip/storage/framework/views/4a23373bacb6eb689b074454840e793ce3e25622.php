<nav class="">
    <div class="nav-bar nav--absolute">
        <div class="nav-module logo-module left">
            <a href="<?php echo e(route('homepage')); ?>">
                <img class="logo logo-light" alt="logo" src="<?php echo e(asset('img/logo-light.png')); ?>" />
                <img class="logo logo-dark" alt="logo" src="<?php echo e(asset('img/logo-dark.png')); ?>" />
            </a>
        </div>
        <div class="nav-module menu-module left">
            <ul class="menu">
                <li>
                    <a href="<?php echo e(route('homepage')); ?>">
                        Home
                    </a>
                   
                </li>
                
            </ul>
        </div>

        <div class="nav-module menu-module right" style = "margin-right: 25px;">
            <ul class="menu">
                <li>
                    <a href="<?php echo e(route('register')); ?>">
                        Register
                    </a> 

                    
                </li>
                    
                <li>
                    <a href="<?php echo e(route('login')); ?>">
                        Login
                    </a> 
                </li>

                <?php if(auth()->check()): ?>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>">
                            Dashboard
                        </a> 
                    </li>
                <?php else: ?>

                <?php endif; ?>

                
                
            </ul>
        </div>       
    </div>
    <!--end nav bar-->
    <div class="nav-mobile-toggle visible-sm visible-xs">
        <i class="icon-Align-Right icon icon--sm"></i>
    </div>
</nav>