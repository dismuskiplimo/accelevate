<div class="modal fade" id="answer-group-assignment">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('student.group-assignment.answers', ['id' => $group->id, 'assignment_id' => $assignment->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Answer Assignment</h4>
        </div>
        
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-12">
              <p><?php echo e($assignment->question); ?></p>
              <div class="form-group">
                  <label for="">Answer</label>
                  <textarea name="answer" id="" cols="" rows="3" required="" class="form-control"></textarea>
              </div>

              
            </div> 
          </div>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Post Answer</button>
        </div>
      </form>
    </div>
  </div>
</div>