<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <div class="card">
                

                <div class="card-body">
                    <img src="<?php echo e(asset('img/default-user.png')); ?>" alt="" class="img-fluid">
                    
                    <p class = "text-center">
                            <br><small>
                                <strong>Name </strong><br><?php echo e($user->name); ?> <br> <br>
                                <strong>Institution  </strong><br><?php echo e($user->school->name); ?> <br> <br>
                                <strong>Email </strong><br> <?php echo e($user->email); ?> <br>
                            </small>
                            
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-5">
           
            <div class="card border-info">
                <div class="card-header">Review Student</div>

                <div class="card-body">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="">Review</label>
                            <textarea id="" rows="3" name="review" class="form-control" required=""></textarea>
                        </div>

                        <button class="btn btn-info" type="submit">Submit Review</button>
                    </form>
                </div>
            </div>

            <br><h3>Reviews (<?php echo e(number_format(count($user->reviews))); ?>)</h3>

            <?php if(count($user->reviews)): ?>
                <?php $__currentLoopData = $user->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card border-secondary">
                        <div class="card-body">
                            <p>
                                <strong><?php echo e($review->staff->name); ?>,</strong> <small><?php echo e($review->created_at->diffForHumans()); ?></small> <br>

                                <small><?php echo e($review->review); ?></small>
                            </p>
                        </div>
                    </div> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No reviews made</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>