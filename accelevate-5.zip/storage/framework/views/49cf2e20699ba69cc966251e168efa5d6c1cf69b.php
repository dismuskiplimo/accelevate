<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-50">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading"><?php echo e($project->question); ?></div>

                <div class="panel-body">
                   

                    <div class="row">
                        <div class="col-lg-12">
                           
                            <h3>Question : <?php echo e($project->question); ?></h3>
                            <h4>Posted To : <?php echo e($project->school->name); ?></h4>
                            <h5>Posted : <?php echo e($project->created_at->diffForHumans()); ?></h5>
                            <p>Answers : <?php echo e(count($project->answers)); ?></p>
   
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="panel panel-primary">
                <div class="panel-heading">Answers</div>
            </div>

            <?php if(count($project->answers)): ?>
                <?php $__currentLoopData = $project->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-8">
                                    <h3><a href="<?php echo e(route('staff.user', ['id' => $answer->user->id])); ?>"><?php echo e($answer->user->name); ?></a></h3>
                                </div>

                                <div class="col-sm-4">
                                    <a href="" data-toggle="modal" data-target="#mark-project-answer-<?php echo e($answer->id); ?>" class="btn btn-info btn-sm float-right"><i class="fa fa-check"></i></a>

                                    <?php echo $__env->make('pages.staff.modals.mark-project-answer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            </div>
                            
                            <p>
                                <strong>Posted :</strong> <?php echo e($answer->created_at->diffForHumans()); ?>

                                <br>

                               <strong>Answer:</strong>  <br> <?php echo e($answer->answer); ?> <br>

                               <strong>Attachments:</strong> <br>

                               <?php if(count($answer->attachments)): ?>

                                    <ul>
                                        <?php $__currentLoopData = $answer->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('download', ['id' => $attachment->id])); ?>"><?php echo e($attachment->filename); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul> <br>

                               <?php endif; ?> 

                               <br><strong>Marks: </strong><?php echo e($answer->getMarks()); ?> <br>
                            </p>
                        </div>
                        
                        
                    </div> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h3>No answers for this project</h3>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>