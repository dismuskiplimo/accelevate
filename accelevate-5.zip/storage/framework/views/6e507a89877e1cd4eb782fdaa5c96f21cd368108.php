<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row" style="position:relative; margin-top:-15px;">
        <img src="<?php echo e($user->cover()); ?>" alt="" class="img-responsive img-fluid">

        <button class="btn btn-info cover-picture cover-edit" type="button"><i class="fa fa-edit"></i> Update Cover Image</button>

        <form action="<?php echo e(route('update-cover')); ?>" method="POST" enctype="multipart/form-data" class="hidden cover-form">
            <?php echo csrf_field(); ?>
            <input type="file" name="image"  class="cover-file">
        </form>
    </div>
    

    <div class="container" style="position:relative">
        <div class="row  thumbnail-float">
            <div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 col-xl-2">
                <img src="<?php echo e($user->image()); ?>" alt="" class="img-responsive img-fluid img-circle circle profile-picture white-border" title="Click to update profile picture">

                <form action="<?php echo e(route('update-image')); ?>" method="POST" enctype="multipart/form-data" class="hidden image-form">
                    <?php echo csrf_field(); ?>
                    <input type="file" name="image" class="image-file">
                </form>
            </div>  

            <div class="col-xs-6 col-sm-6 col-md-8 col-lg-9 col-xl-10">
                <h1 class="white-text mt-25"><?php echo e($user->name); ?></h1>
            </div> 
        </div>
    </div>
    
</div>

<div class="container">
    

    <div class="row mt-50">
        <div class="col-md-3">
            <div class="panel">
                

                <div class="panel-body">
                    
                    
                    <p class = "text-center">
                            <br><small>
                                <strong>Name </strong><br><?php echo e($user->name); ?> <br> <br>
                                <strong>Institution  </strong><br><?php echo e($user->school->name); ?> <br> <br>
                                <strong>Email </strong><br> <?php echo e($user->email); ?> <br>
                            </small>
                            
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">

            <div class="panel panel-default mb-20">
                <div class="panel-heading">User Details</div>
                <div class="panel-body">
                    <form action="<?php echo e(route('update-profile')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($user->name); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($user->email); ?>" required>
                        </div>

                        <button class="btn btn-info" type="submit">Update Profile</button>
                    </form>        
                </div>
            </div>

            <div class="panel panel-default mb-20">
                <div class="panel-heading">Password</div>
                <div class="panel-body">
                    <form action="<?php echo e(route('update-password')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="old_password">Old Password</label>
                            <input id="old_password" type="password" class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" name="old_password" required>
                        </div>

                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input id="new_password" type="password" class="form-control<?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>" name="new_password" required>
                        </div>

                        <div class="form-group">
                            <label for="password_confirmation">Retype New Password</label>
                            <input id="password_confirmation" type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="new_password_confirmation" required>
                        </div>

                        <button class="btn btn-info" type="submit">Change Password</button>
                    </form>        
                </div>
            </div>
            

            <?php if($user->is_student()): ?>
                <h3>Reviews (<?php echo e(number_format(count($user->reviews))); ?>)</h3>

                <?php if(count($user->reviews)): ?>
                    <?php $__currentLoopData = $user->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <p>
                                    <strong><?php echo e($review->staff->name); ?>,</strong> <small><?php echo e($review->created_at->diffForHumans()); ?></small> <br>

                                    <small><?php echo e($review->review); ?></small>
                                </p>
                            </div>
                        </div> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>No reviews made</p>
                <?php endif; ?>    
            <?php endif; ?>

            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>