<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-50" style="min-height:400px">
        <div class="col-md-8 col-md-offset-2">
            <p class="text-right">
            	<a href="" data-toggle="modal" data-target="#add-event" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> ADD EVENT</a>
            </p>

            <div class="panel panel-info">
                <div class="panel-heading">Events (<?php echo e(number_format(count($events))); ?>)</div>

                <div class="panel-body">
                    <?php if(count($events)): ?>
						<table class="table table-striped">
							<thead>
								<tr>
									<th></th>
									<th>Date</th>
									<th>Event</th>
									<th>Location</th>
									<th>Description</th>
									<th></th>
								</tr>
							</thead>

							<tbody>
								<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td></td>
										<td><?php echo e($event->date); ?></td>
										<td><?php echo e($event->name); ?></td>
										<td><?php echo e($event->location); ?></td>
										<td><?php echo e($event->description); ?></td>
										<td class="text-right">
											<form action="<?php echo e(route('admin.event.delete', ['id' => $event->id])); ?>" method="POST">
												<?php echo csrf_field(); ?>

												<button type="submit" class="btn btn-danger btn-xs" title="Dalete <?php echo e($event->name); ?>"><i class="fa fa-trash"></i></button></td>
									</tr>
											</form>
											
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
                    <?php else: ?>
						<p>No Events Posted</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('pages.admin.modals.add-event', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>