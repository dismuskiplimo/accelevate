<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-50" style="min-height:400px">
        <div class="col-md-8 col-md-offset-2">
            <p class="text-right">
                <button data-toggle="modal" data-target="#add-group" class="btn btn-success btn-sm" type="button"><i class="fa fa-plus"></i> ADD GROUP</button>    
            </p>
            
            <div class="panel panel-info">
                <div class="panel-heading">My Groups (<?php echo e(number_format(count($groups))); ?>)</div>

                <div class="panel-body">
                   

                    <div class="row">
                        <div class="col-lg-12">
                           
                            <?php if(count($groups)): ?>
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Group Name</th>
                                            <th class="text-right">Members</th>
                                            <th class="text-right">Assignments</th>
                                            <th></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($group->name); ?></td>
                                                <td class="text-right"><?php echo e(number_format(count($group->members))); ?></td>
                                                <td class="text-right"><?php echo e(number_format(count($group->assignments))); ?></td>
                                                <td class="text-right"><a href="<?php echo e(route('staff.group-assignments', ['id' => $group->id])); ?>" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i></a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                No groups created
                            <?php endif; ?>
   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('pages.staff.modals.add-group', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>