<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-50" style="min-height:400px">
        <div class="col-md-8 col-md-offset-2">
            <p class="text-right">
                <a href="<?php echo e(route('staff.group-assignments', ['id' => $group->id])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-list"></i> ASSIGNMENTS</a>

                <button data-toggle="modal" data-target="#add-group-member" class="btn btn-success btn-sm right" type="button"><i class="fa fa-plus"></i> ADD MEMBER</button>    
            </p>
            
            <div class="panel panel-info">
                <div class="panel-heading"><?php echo e($group->name); ?></div>

                <div class="panel-body">
                   

                    <div class="row">
                        <div class="col-lg-12">
                           <h4>Members:</h4>
                            <?php if(count($members)): ?>
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>School</th>
                                            <th></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($member->student->name); ?></td>
                                                <td><?php echo e($member->student->school->name); ?></td>
                                                <td class="text-right"><a href="<?php echo e(route('staff.user', ['id' => $member->student->id])); ?>" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i></a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                No members in this group
                            <?php endif; ?>
   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('pages.staff.modals.add-group-member', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>