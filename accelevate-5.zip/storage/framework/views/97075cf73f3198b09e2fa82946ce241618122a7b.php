<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row" style="position:relative">
        <img src="<?php echo e($user->cover()); ?>" alt="" class="img-responsive">
       
    </div>
    

    <div class="container" style="position:relative">
        <div class="row  thumbnail-float">
            <div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 col-xl-2">
                <img src="<?php echo e($user->image()); ?>" alt="" class="img-responsive img-circle white-border">
                
            </div>  

            <div class="col-xs-6 col-sm-6 col-md-8 col-lg-9 col-xl-10">
                <h1 class="white-text mt-75"><?php echo e($user->name); ?></h1>
            </div> 
        </div>
    </div>
    
</div>

<div class="container">
    <div class="row mt-50">
        <div class="col-md-3">
            <div class="panel">
                

                <div class="panel-body">
                    
                    
                    <p class = "text-center">
                            <br><small>
                                <strong>Name </strong><br><?php echo e($user->name); ?> <br> <br>
                                <strong>Institution  </strong><br><?php echo e($user->school->name); ?> <br> <br>
                                <strong>Email </strong><br> <?php echo e($user->email); ?> <br>
                            </small>
                            
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
           
            <div class="panel panel-info">
                <div class="panel-heading">Review Student</div>

                <div class="panel-body">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="">Review</label>
                            <textarea id="" rows="3" name="review" class="form-control" required=""></textarea>
                        </div>

                        <button class="btn btn-info" type="submit">Submit Review</button>
                    </form>
                </div>
            </div>

            <br><h3>Reviews (<?php echo e(number_format(count($user->reviews))); ?>)</h3>

            <?php if(count($user->reviews)): ?>
                <?php $__currentLoopData = $user->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <p>
                                <strong><?php echo e($review->staff->name); ?>,</strong> <small><?php echo e($review->created_at->diffForHumans()); ?></small> <br>

                                <small><?php echo e($review->review); ?></small>
                            </p>
                        </div>
                    </div> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No reviews made</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.bootstrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>