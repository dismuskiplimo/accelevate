<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($project->question); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-lg-12">
                           
                            <h3>Question : <?php echo e($project->question); ?></h3>
                            <h4>Posted To : <?php echo e($project->school->name); ?></h4>
                            <h5>Posted : <?php echo e($project->created_at->diffForHumans()); ?></h5>
                            <p>Answers : <?php echo e(count($project->answers)); ?></p>
   
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="card">
                <div class="card-header">Answer</div>

                <div class="card-body">
                    <h4>My Answer</h4>

                    <?php if($answer): ?>
                        
                        
                        Posted : <?php echo e($answer->created_at); ?> <br>
                        Answer : <?php echo e($answer->answer); ?> <br>
                        Attachments : <br>

                        <?php if(count($answer->attachments)): ?>
                            <ul>
                                <?php $__currentLoopData = $answer->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('download', ['id' => $attachment->id])); ?>"><?php echo e($attachment->filename); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </ul>
                            
                        <?php else: ?>
                            No Attachment
                        <?php endif; ?>
                    <?php else: ?>
                        

                        <form action="" method = "POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="">Answer</label>
                                <input type="text" class="form-control" name="answer" required="">
                            </div>

                            <div class="form-group">
                                <label for="">Attachment</label> <br>
                                <input type="file" name="attachment">
                            </div>

                            <button class="btn btn-info" type="submit">Post Answer</button>
                        </form>


                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>