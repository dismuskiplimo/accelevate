<div class="modal fade" id="add-group-member">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('staff.group-member.add', ['id' => $group->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Add Group Member</h4>
        </div>
        
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label for="skill-1">Student</label>
                <select name="student_id" id="student_id" required="" class="form-control">
                  <option value="">--Select Student--</option>

                  <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($student->id, $ids)): ?>
                      <?php
                        continue;
                      ?>
                    <?php endif; ?>
                    <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
              </div>
            </div>
          </div>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add Student to Group</button>
        </div>
      </form>
    </div>
  </div>
</div>