<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row mtn-15" style="position:relative">
        <img src="<?php echo e($user->cover()); ?>" alt="" class="img-fluid img-responsive">
       
    </div>
    

    <div class="container" style="position:relative">
        <div class="row  thumbnail-float">
            <div class="col-xs-6 col-sm-6 col-md-4 col-lg-3 col-xl-2">
                <img src="<?php echo e($user->image()); ?>" alt="" class="img-responsive img-fluid circle  img-circle white-border">
                
            </div>  

            <div class="col-xs-6 col-sm-6 col-md-8 col-lg-9 col-xl-10">
                <h1 class="white-text mt-25"><?php echo e($user->name); ?></h1>
            </div> 
        </div>
    </div>
    
</div>

<div class="container">
    <div class="row mt-50">
        <div class="col-md-3">
            <div class="panel">
                

                <div class="panel-body">
                    
                    
                    <p class = "text-center">
                            <br><small>
                                <strong>Name </strong><br><?php echo e($user->name); ?> <br> <br>
                                <strong>Institution  </strong><br><?php echo e($user->school->name); ?> <br> <br>
                                <strong>Email </strong><br> <?php echo e($user->email); ?> <br>
                            </small>
                            
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
           
            <?php if($user->is_student() && !$me): ?>
                <div class="panel panel-info">
                    <div class="panel-heading">Review Student</div>

                    <div class="panel-body">
                        <form action="<?php echo e(route('user.review', ['id' => $user->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                             <div class="form-group">
                                <label for="">Rating</label>

                                <div class="radio text-warning">
                                    <input type="radio" name="rating" id="" value="1">
                                    <i class="fa fa-star mr-10"></i>

                                    <input type="radio" name="rating" id="" value="2">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star mr-10"></i>

                                    <input type="radio" name="rating" id="" value="3" checked="">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star mr-10"></i>

                                    <input type="radio" name="rating" id="" value="4">
                                    <i class="fa fa-star"></i> 
                                    <i class="fa fa-star"></i> 
                                    <i class="fa fa-star"></i> 
                                    <i class="fa fa-star mr-10"></i> 
                                    
                                    <input type="radio" name="rating" id="" value="5"> 
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i> 
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="">Review</label>
                                <textarea id="" rows="3" name="review" class="form-control" required=""></textarea>
                            </div>

                            <button class="btn btn-info" type="submit">Submit Review</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

            <br><h3>Reviews (<?php echo e(number_format(count($user->reviews))); ?>)</h3>

            <?php if(count($user->reviews)): ?>
                <?php $__currentLoopData = $user->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <p>
                                <strong><?php echo e($review->staff->name); ?> 

                                    <?php for($i = 0 ; $i< $review->rating; $i++): ?>
                                        <i class="fa fa-star text-warning"></i>
                                    <?php endfor; ?>

                                </strong> <small>, <?php echo e($review->created_at->diffForHumans()); ?></small> <br>

                                <small><?php echo e($review->review); ?></small>
                            </p>
                        </div>
                    </div> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No reviews made</p>
            <?php endif; ?>

            <div class="row">
                <div class="col-sm-12">
                            <h4>ABOUT ME</h4>

                            <h5>
                                About:

                                <?php if($me): ?>
                                    <a href="" data-toggle="modal" data-target="#about-me" class="btn btn-xs btn-info pull-right">Edit</a>
                                <?php endif; ?>
                            </h5>
                            <hr class = "mtn-5">
                            <?php echo clean(nl2br($user->about_me ? : 'No Details')); ?>

                                
                            
                            <br>
                                <h5>
                                    Memberships:
                                    <?php if($me): ?>
                                        <a href="" data-toggle="modal" data-target="#add-membership" class="btn btn-xs btn-info pull-right"><i class="fa fa-plus"></i> Add Membership</a>
                                    <?php endif; ?>
                                </h5>
                            <hr class = "mtn-5">
                            
                            <?php if(count($user->memberships)): ?>
                                
                                <ul class="ml-20">
                                    <?php $__currentLoopData = $user->memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($membership->name); ?>

                                            <?php if($me): ?>
                                                <span class="pull-right">
                                                    <button class="btn btn-warning btn-xs" type="button"  data-toggle="modal" data-target="#edit-membership-<?php echo e($membership->id); ?>"  title="edit <?php echo e($membership->name); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </button> 

                                                    <button class="btn btn-danger btn-xs" type="button" data-toggle="modal" data-target="#delete-membership-<?php echo e($membership->id); ?>" title="delete <?php echo e($membership->name); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </button> 
                                                </span>

                                                <?php echo $__env->make('pages.user.modals.edit-membership', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('pages.user.modals.delete-membership', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            <?php else: ?>
                                <p class="ml-20">No Memberships Stated</p>
                            <?php endif; ?>

                            <h5>
                                Education:
                                <?php if($me): ?>
                                    <a href="" data-toggle="modal" data-target="#add-education" class="btn btn-xs btn-info pull-right"><i class="fa fa-plus"></i> Add Education</a>
                                <?php endif; ?>
                            </h5>
                            <hr class = "mtn-5">
                            <div>
                                <?php if(count($user->education)): ?>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>School</th>
                                                <th>Level</th>
                                                <th>Field of Study</th>
                                                <th>Grade</th>

                                                <?php if($me): ?>
                                                    <th></th>
                                                <?php endif; ?>
                                            </tr>
                                            
                                            
                                            
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $user->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($education->start_year); ?></td>
                                                    <td><?php echo e($education->end_year); ?></td>
                                                    <td><?php echo e($education->school); ?></td>
                                                    <td><?php echo e($education->level); ?></td>
                                                    <td><?php echo e($education->field_of_study); ?></td>
                                                    <td><?php echo e($education->grade); ?></td>
                                                    
                                                    <?php if($me): ?>
                                                        <td>
                                                            <?php echo $__env->make('pages.user.modals.edit-education', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                            <?php echo $__env->make('pages.user.modals.delete-education', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                        </td>

                                                        <td class="text-right">
                                                            <button class="btn btn-warning btn-xs" type="button"  data-toggle="modal" data-target="#edit-education-<?php echo e($education->id); ?>"  title="edit <?php echo e($education->school); ?>">
                                                                <i class="fa fa-edit"></i>
                                                            </button> 

                                                            <button class="btn btn-danger btn-xs" type="button" data-toggle="modal" data-target="#delete-education-<?php echo e($education->id); ?>" title="delete <?php echo e($education->school); ?>">
                                                                <i class="fa fa-trash"></i>
                                                            </button>   

                                                            
                                                        </td>

                                                        
                                                    <?php endif; ?>
                                                    
                                                </tr>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        
                                    </table>
                                <?php else: ?>
                                    <p class="ml-20">No Education Info</p>
                                <?php endif; ?>
                            </div>

                            <h5>
                                Work Experience:
                                <?php if($me): ?>
                                    <a href="" data-toggle="modal" data-target="#add-work-experience" class="btn btn-xs btn-info pull-right"><i class="fa fa-plus"></i> Add Work Experience</a>
                                <?php endif; ?>
                            </h5>
                            
                            <hr class = "mtn-5">
                            <div>
                                <?php if(count($user->work_experience)): ?>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>Company</th>
                                                <th>Position</th>

                                                <?php if($me): ?>
                                                    <th></th>
                                                <?php endif; ?>
                                            </tr>
                                            
                                            
                                            
                                            
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $user->work_experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work_experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($work_experience->from_date); ?></td>
                                                    <td><?php echo e($work_experience->to_date); ?></td>
                                                    <td><?php echo e($work_experience->company); ?></td>
                                                    <td><?php echo e($work_experience->position); ?></td>
                                                    
                                                    <?php if($me): ?>
                                                        <td>
                                                            <?php echo $__env->make('pages.user.modals.edit-work-experience', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                            <?php echo $__env->make('pages.user.modals.delete-work-experience', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                        </td>

                                                        <td class="text-right">
                                                            <button class="btn btn-warning btn-xs" type="button"  data-toggle="modal" data-target="#edit-work-experience-<?php echo e($work_experience->id); ?>"  title="edit <?php echo e($work_experience->company); ?>">
                                                                <i class="fa fa-edit"></i>
                                                            </button> 

                                                            <button class="btn btn-danger btn-xs" type="button" data-toggle="modal" data-target="#delete-work-experience-<?php echo e($work_experience->id); ?>" title="delete <?php echo e($work_experience->company); ?>">
                                                                <i class="fa fa-trash"></i>
                                                            </button> 

                                                        </td>


                                                    <?php endif; ?>
                                                </tr>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        
                                    </table>
                                <?php else: ?>
                                    <p class="ml-20">No Work Expereince Stated</p>
                                <?php endif; ?>
                            </div>
                            
                            <br>

                            <h5>
                                Skills:
                                <?php if($me): ?>
                                    <a href="" data-toggle="modal" data-target="#add-skill" class="btn btn-xs btn-info pull-right"><i class="fa fa-plus"></i> Add Skill</a>
                                <?php endif; ?>
                            </h5>
                            <hr class = "mtn-5">
                            
                            <?php if(count($user->skills)): ?>
                                <ul class="ml-20">
                                    <?php $__currentLoopData = $user->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($skill->skill); ?>

                                            
                                            <?php if($me): ?>
                                                <span class="pull-right">
                                                    <button class="btn btn-warning btn-xs" type="button"  data-toggle="modal" data-target="#edit-skill-<?php echo e($skill->id); ?>"  title="edit <?php echo e($skill->skill); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </button> 

                                                    <button class="btn btn-danger btn-xs" type="button" data-toggle="modal" data-target="#delete-skill-<?php echo e($skill->id); ?>" title="delete <?php echo e($skill->skill); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </button> 
                                                </span>

                                                <?php echo $__env->make('pages.user.modals.edit-skill', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('pages.user.modals.delete-skill', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php endif; ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                

                            <?php else: ?>
                                <p class="ml-20">No Skills Stated</p>
                            <?php endif; ?>
                            
                            <br>

                            <h5>
                                Awards:
                                <?php if($me): ?>
                                    <a href="" data-toggle="modal" data-target="#add-award" class="btn btn-xs btn-info pull-right"><i class="fa fa-plus"></i> Add Award</a>
                                <?php endif; ?>
                            </h5>
                            <hr class = "mtn-5">
                            
                            <?php if(count($user->awards)): ?>
                                <ul class="ml-20">
                                    <?php $__currentLoopData = $user->awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($award->name); ?>, <?php echo e($award->year); ?> 
                                            
                                            <?php if($me): ?>
                                                <span class="pull-right">
                                                    <button class="btn btn-warning btn-xs" type="button"  data-toggle="modal" data-target="#edit-award-<?php echo e($award->id); ?>"  title="edit <?php echo e($award->name); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </button> 

                                                    <button class="btn btn-danger btn-xs" type="button" data-toggle="modal" data-target="#delete-award-<?php echo e($award->id); ?>" title="delete <?php echo e($award->name); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </button> 
                                                </span>

                                                <?php echo $__env->make('pages.user.modals.edit-award', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('pages.user.modals.delete-award', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                

                            <?php else: ?>
                                <p class="ml-20">No Awards Stated</p>
                            <?php endif; ?>

                            <br>
                            <h5>
                                Hobbies:
                                <?php if($me): ?>
                                    <a href="" data-toggle="modal" data-target="#add-hobby" class="btn btn-xs btn-info pull-right"><i class="fa fa-plus"></i> Add Hobby</a>
                                <?php endif; ?>
                            </h5>
                            <hr class = "mtn-5">

                            <?php if(count($user->hobbies)): ?>                        
                                <ul class="ml-20">
                                    <?php $__currentLoopData = $user->hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($hobby->name); ?>


                                            <?php if($me): ?>
                                                <span class="pull-right">
                                                    <button class="btn btn-warning btn-xs" type="button"  data-toggle="modal" data-target="#edit-hobby-<?php echo e($hobby->id); ?>"  title="edit <?php echo e($hobby->name); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </button> 

                                                    <button class="btn btn-danger btn-xs" type="button" data-toggle="modal" data-target="#delete-hobby-<?php echo e($hobby->id); ?>" title="delete <?php echo e($hobby->name); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </button> 
                                                </span>

                                                <?php echo $__env->make('pages.user.modals.edit-hobby', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('pages.user.modals.delete-hobby', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                                <p class="ml-20">No Hobbies Stated</p>
                            <?php endif; ?>

                            <br>
                            <h5>
                                Achievements:
                                <?php if($me): ?>
                                    <a href="" data-toggle="modal" data-target="#add-achievement" class="btn btn-xs btn-info pull-right"><i class="fa fa-plus"></i> Add Achievements</a>
                                <?php endif; ?>
                            </h5>
                            <hr class = "mtn-5">

                            <?php if(count($user->achievements)): ?>
                                
                                <ul class="ml-20">
                                    <?php $__currentLoopData = $user->achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($achievement->name); ?>


                                            <?php if($me): ?>
                                                <span class="pull-right">
                                                    <button class="btn btn-warning btn-xs" type="button"  data-toggle="modal" data-target="#edit-achievment-<?php echo e($achievement->id); ?>"  title="edit <?php echo e($achievement->name); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </button> 

                                                    <button class="btn btn-danger btn-xs" type="button" data-toggle="modal" data-target="#delete-achievement-<?php echo e($achievement->id); ?>" title="delete <?php echo e($achievement->name); ?>">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </span>

                                                <?php echo $__env->make('pages.user.modals.edit-achievement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                                <?php echo $__env->make('pages.user.modals.delete-achievement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                
                            <?php else: ?>
                                <p class="ml-20">No Achievements Stated</p>
                            <?php endif; ?>
                        </div>
            </div>
        </div>
    </div>
</div>

<?php if($me): ?>
    <?php echo $__env->make('pages.user.modals.about-me', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.user.modals.add-membership', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.user.modals.add-award', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.user.modals.add-hobby', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.user.modals.add-achievement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.user.modals.add-education', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.user.modals.add-work-experience', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('pages.user.modals.add-skill', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>