<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-50">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">Create Project</div>

                <div class="panel-body">
                    
                    <div class="row">
                        <div class="col-lg-12">
                           

                            <form action="<?php echo e(route('dashboard.staff')); ?>" method = "POST">
                                <?php echo csrf_field(); ?>
                                
                                <div class="form-group">
                                    <label for="">Question</label>
                                    <textarea name="question" id="" cols="" rows="3" required="" class="form-control"></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="">Post To:</label>
                                    <select name="school_id" id="" required="" class="form-control">
                                        <option value=""> --Select Institution-- </option>
                                        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($school->id); ?>"><?php echo e($school->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                   
                                </div>

                                <button type="submit" class="btn btn-info">Submit</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="panel panel-info">
                <div class="panel-heading">My Projects</div>

                <div class="panel-body">
                    <?php if(count($projects)): ?>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    
                                    <h3><a href="<?php echo e(route('staff.project', ['slug' => $project->slug])); ?>"><?php echo e($project->question); ?></a></h3>
                                    <p>
                                        Posted to : <strong><?php echo e($project->school ? $project->school->name : 'N/A'); ?></strong>
                                        <br>


                                       Answers: <?php echo e(count($project->answers)); ?> 

                                       <small>
                                            <span class="float-right"><?php echo e($project->created_at->diffForHumans()); ?></span>
                                            
                                        </small>
                                    </p>
                                    
                                </div>
                               
                                
                            </div> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h3>You havent posted any projects</h3>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>