<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-50" style="min-height:400px">
        <div class="col-md-8 col-md-offset-2">
            <p class=" text-right">
                
                <a href="<?php echo e(route('student.group-assignments', ['id' => $group->id])); ?>" class="btn btn-warning btn-sm"><i class="fa fa-arrow-left"></i> BACK TO GROUP</a>
                        
            </p>

            <div class="panel panel-default">
                <div class="panel-heading">Group : <?php echo e($group->name); ?></div>

                <div class="panel-body">
                   

                    <div class="row">
                        <div class="col-lg-12">
                           <h4>Group Discussion(<?php echo e(number_format($discussions->total())); ?>)</h4>
                            
                            <div class="div">
                                <form action="<?php echo e(route('discussion.post', ['id' => $group->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label for="">What would you like to post?</label>
                                        <textarea name="content" class="form-control" id="" rows="5" required="" placeholder="write something"></textarea>
                                    </div>

                                    <button class="btn btn-info" type="submit">POST</button>
                                </form>

                                <hr>
                            </div>
                            <?php if($discussions->total()): ?>
                                <?php $__currentLoopData = $discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="media">
                                      <a href="<?php echo e(route('staff.user', ['id' => $discussion->user->id])); ?>">
                                      <img class="mr-3 size-40" src="<?php echo e($discussion->user->image()); ?>" alt="Generic placeholder image">
                                      </a>
                                      <div class="media-body">
                                        <h5 class="mt-0"><small><?php echo e($discussion->user->name); ?></a> | <small class="text-muted tiny"><?php echo e($discussion->created_at->diffForHumans()); ?></small> </small></h5>
                                        
                                        <p><?php echo e($discussion->content); ?></p>

                                        <p>Comments(<?php echo e(count($discussion->comments)); ?>)</p>

                                        <hr>

                                        <?php if($discussion->comments): ?>
                                            <?php $__currentLoopData = $discussion->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="media mt-3">
                                                  <a class="pr-3" href="<?php echo e(route('staff.user', ['id' => $comment->user->id])); ?>">
                                                    <img src="<?php echo e($comment->user->image()); ?>" alt="Generic placeholder image" class="size-40">
                                                  </a>
                                                  <div class="media-body">
                                                    <h5 class="mt-0"><small><?php echo e($comment->user->name); ?></a> | <small class="text-muted tiny"><?php echo e($comment->created_at->diffForHumans()); ?></small></small></h5>
                                                    
                                                    <p><?php echo e($comment->content); ?></p>

                                                  </div>
                                                </div>

                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <form action="<?php echo e(route('comment.post', ['id' => $discussion->id])); ?>" method = "POST">
                                            <?php echo csrf_field(); ?>
                                            
                                            <div class="form-group">
                                                
                                                <textarea name="content" class="form-control" id="" rows="3" required="" placeholder="write comment"></textarea>
                                            </div>

                                            <button class="btn btn-info" type="submit">Comment</button>

                                        </form>

                                        
                                      </div>
                                    </div>

                                    

                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e($discussions->links()); ?>

                               
                            <?php else: ?>
                                No discussions in this group
                            <?php endif; ?>
   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>