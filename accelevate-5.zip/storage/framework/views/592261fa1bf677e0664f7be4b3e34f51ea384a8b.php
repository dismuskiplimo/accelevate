<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<?php if(count($events)): ?>
			<div class="row">
				<div id="item-carousel" class="carousel slide" data-ride="carousel">
					<!-- Indicators -->
					<ol class="carousel-indicators">
						

						<?php for($cnt = 0; $cnt < count($events); $cnt++): ?>
							
							<li data-target="#item-carousel" data-slide-to="<?php echo e($cnt); ?>" class="<?php echo e($cnt == 0 ? 'active' : ''); ?>"></li>
							
						<?php endfor; ?>
						
						
					</ol>

					<!-- Wrapper for slides -->
					<div class="carousel-inner" role="listbox">
						<?php
							$cnt = 0;
						?>

						<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item<?php echo e($cnt == 0 ? ' active' : ''); ?>">
								<img src="<?php echo e($event->image()); ?>" alt="<?php echo e($event->name); ?>">
								
								<div class="carousel-caption">
						        	<h4><?php echo e($event->name); ?></h4>
						        	<h5><?php echo e($event->date); ?></h5>
						        	<p><?php echo e($event->description); ?></p>
						      	</div>
							</div>

							<?php
								$cnt++;
							?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>

					<!-- Controls -->
					<a class="left carousel-control" href="#item-carousel" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left fa fa-arrow-left" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					
					<a class="right carousel-control" href="#item-carousel" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right fa fa-arrow-right" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>	
			</div>
			
		<?php else: ?>
			<div class="row banner-image fullscreen text-center">
				<div class="centered col-sm-6">
					<img src="<?php echo e(asset('img/logo-large-light.png')); ?>" alt="" class="img-responsive mb-50">
					
					
						<a href="<?php echo e(route('register')); ?>" class="btn btn-lg btn-primary" style="margin-right:20px"><i class="fa fa-user"></i> Register</a>
						<a href="<?php echo e(route('login')); ?>" class="btn btn-lg btn-success"><i class="fa fa-sign-in"></i> Login</a>
					
					

				</div>
			</div>
		<?php endif; ?>
	</div>

	

    <!-- Services -->
    <section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">What we do</h2>
          </div>
        </div>
        <div class="text-center">
          	<p>Accelevate Leads organizes experiential skills training programs where students get to interact with personnel from various companies and organizations. Through partnerships with companies, we organize Skills Hunt Summits, Skills hunt competition, Mentorships, Internships which serve as information platforms for students on soft and hard skills. </p>
			<p>We have created a space for an initiative that exposes Final Year students and Graduates to Relevant skills the job market needs and by the employers. Furthermore, students are also given an opportunity to be exposed to career paths that they studied in turn they are able to decide which career path suits their desire and we encourage them to pursue them.</p>
        </div>
      </div>
    </section>

    <!-- Portfolio Grid -->
    <section class="bg-light" id="portfolio">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Who we are</h2>
          </div>
        </div>
        <div class="text-center">
        	 <p>
				We are a skill development firm whose core objective is to bridge the gap between the job market demands and the school curriculum. We create economic mobility for the unemployed by encouraging students in institutions of higher learning to get skills and take available opportunities. Accelevate Leads Limited was founded in 2014 by Ms. Viridiana Wasike. It was established to address the graduate unemployment menace.


			</p>

			<p>
				We believe the skills hunt program has and continues to be an amazing platform for students and graduates. It provides exposure to challenges that aim to sharpen soft skills which makes up 80% of any job requirement. 
			</p>
        </div>
      </div>
    </section>

    <!-- About -->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Partnerships</h2>
          </div>
        </div>
        <div class="row text-center">
          <div class="col-lg-12">
           	<p>
				We have partnered with quite the number of organizations in addressing Skills Development needed in the job market by collaborating/partnering with various companies and organizations in solving the problem of graduate unemployment. Our partners are: One Acre Fund, Centum, Questworks, Moringa School, Telkom, Safaricom, IBM, Microsoft, Kenya Medical Research Institute (KEMRI), among others.   (Insert logos for the mentioned organizations).
			</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Team -->
    <section class="bg-light" id="team">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Problem Statement</h2>
            
          </div>
        </div>
        <div class="text-center">
        	<p>
				Over the years students complete their higher education from various institutions expecting to be absorbed into the job market where they would apply the knowledge gained from class. However, many have had their applications rejected and their dreams shattered causing them to organize demos so as to express their dissatisfaction with the employers. 
			</p>	

			<p>
				On the other hand the employers have shielded themselves from these sentiments citing that many students graduating from institutions of higher learning only have the knowledge disseminated in class but lack the industrial acumen and the valuable skills employers are sorting after hence the narrative that the 8-4-4 students are ‘half-baked’. 
			</p>

			<p>
				Skills hunt is filling the gap as an active information centre for university students and graduates to provide adequate access to skills needed in the market.
			</p>
        </div>
      </div>
    </section>

	

	<!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Contact Us</h2>
            <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <form id="contactForm" name="sentMessage" novalidate="novalidate">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input class="form-control" id="name" type="text" placeholder="Your Name *" required="required" data-validation-required-message="Please enter your name.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" id="email" type="email" placeholder="Your Email *" required="required" data-validation-required-message="Please enter your email address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" id="phone" type="tel" placeholder="Your Phone *" required="required" data-validation-required-message="Please enter your phone number.">
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <textarea class="form-control" id="message" placeholder="Your Message *" required="required" data-validation-required-message="Please enter a message."></textarea>
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-lg-12 text-center">
                  <div id="success"></div>
                  <button id="sendMessageButton" class="btn btn-primary btn-xl text-uppercase" type="submit">Send Message</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>


	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>