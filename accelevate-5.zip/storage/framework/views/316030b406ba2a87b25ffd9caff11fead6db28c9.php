<?php $__env->startSection('content'); ?>
	<div class="container">
		
			<div class="row my-50 h-400">
        
        
        <div class="col-sm-8">
          <h4>Terms of Use</h4>

        </div>
            
        
      </div>
			
		
	</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>