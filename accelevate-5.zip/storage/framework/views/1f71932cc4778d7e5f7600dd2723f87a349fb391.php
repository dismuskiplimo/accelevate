<?php $__env->startSection('content'); ?>
	<div class="container">
		
			<div class="row my-50 h-400">
        
        
        <div class="col-sm-8">
          <div class="card">
            <img src="<?php echo e($event->full_image()); ?>" class="card-img-top" alt="<?php echo e($event->name); ?>"   class="img-fluid">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($event->name); ?>, <small text-muted><?php echo e($event->date); ?></small></h5>
              <h6><?php echo e($event->location); ?></h6>
              <p class="card-text"><?php echo e($event->description); ?></p>
            </div>
          </div>

        </div>
            
        
      </div>
			
		
	</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>