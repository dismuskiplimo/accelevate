<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-50 h-400">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">Projects</div>

               
            </div>

            <?php if(count($projects)): ?>
               <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <br><h4>
                                <a href="<?php echo e(route('student.project', ['slug' => $project->slug])); ?>">Project : <?php echo e($project->question); ?></a></h4>
                            <p>Posted : <?php echo e($project->created_at->diffForHumans()); ?></p>
                            <p>Answers : <?php echo e($project->answers()->count()); ?></p>
                        </div>

                    </div><br>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               <?php echo e($projects->links()); ?>

                
            <?php else: ?>
                <h3 class="text-center">No Projects for your school</h3>
            <?php endif; ?>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>