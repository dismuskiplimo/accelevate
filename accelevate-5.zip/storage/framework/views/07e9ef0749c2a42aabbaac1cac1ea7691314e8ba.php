<?php $__env->startSection('content'); ?>
	<div class="container">
		
			<div class="row my-50 h-400">
        <div class="col-sm-12">
          <h3>Events (<?php echo e(number_format(count($events))); ?>)</h3>
        </div>
        <?php if(count($events)): ?>
          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-4">
                <div class="card">
                  <img src="<?php echo e($event->image()); ?>" class="card-img-top" alt="<?php echo e($event->name); ?>"   class="img-fluid">
                  <div class="card-body">
                    <h5 class="card-title"><?php echo e($event->name); ?>, <small text-muted><?php echo e($event->date); ?></small></h5>
                    <h6><?php echo e($event->location); ?></h6>
                    <p class="card-text"><?php echo e($event->description); ?></p>
                    <a href="<?php echo e(route('front.event', ['id' => $event->id])); ?>" class="btn btn-primary">View Event</a>
                  </div>
                </div>

              </div>
              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <div class="col-sm-12">
            <h4 class="text-center">No Events</h4>
          </div>
          
        <?php endif; ?>
      </div>
			
		
	</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.agency', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>