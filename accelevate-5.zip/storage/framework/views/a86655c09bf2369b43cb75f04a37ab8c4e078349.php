<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($project->question); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-lg-12">
                           
                            <h3>Question : <?php echo e($project->question); ?></h3>
                            <h4>Posted To : <?php echo e($project->school->name); ?></h4>
                            <h5>Posted : <?php echo e($project->created_at->diffForHumans()); ?></h5>
                            <p>Answers : <?php echo e(count($project->answers)); ?></p>
   
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="card">
                <div class="card-header">Answers</div>

                <div class="card-body">
                    <?php if(count($project->answers)): ?>
                        <?php $__currentLoopData = $project->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card border-info">
                                <div class="col-lg-12">
                                    <br><h3><a href="<?php echo e(route('staff.user', ['id' => $answer->user->id])); ?>"><?php echo e($answer->user->name); ?></a></h3>
                                    <p>
                                        <strong>Posted :</strong> <?php echo e($answer->created_at->diffForHumans()); ?>

                                        <br>

                                       <strong>Answer:</strong>  <br> <?php echo e($answer->answer); ?> <br>

                                       <strong>Attachments:</strong> <br>

                                       <?php if(count($answer->attachments)): ?>

                                            <ul>
                                                <?php $__currentLoopData = $answer->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(route('download', ['id' => $attachment->id])); ?>"><?php echo e($attachment->filename); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>

                                       <?php endif; ?> 
                                    </p>
                                </div>
                                
                            </div> <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h3>No answers for this project</h3>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>