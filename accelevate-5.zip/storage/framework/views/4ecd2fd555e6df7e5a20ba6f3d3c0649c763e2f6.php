<ul class="nav navbar-nav">
	<li ><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
</ul>

<ul class="nav navbar-nav navbar-right">
	
	<?php if(auth()->check()): ?>
		<li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
		<?php if(auth()->user()->is_student()): ?>
			<li><a href="<?php echo e(route('student.groups')); ?>">Groups</a></li>
		<?php elseif(auth()->user()->is_staff()): ?>
			<li><a href="<?php echo e(route('staff.groups')); ?>">Groups</a></li>
		<?php endif; ?>
		

		<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> 
				<img src="<?php echo e(profile_thumb(auth()->user()->thumb_url)); ?>" alt="" class="size-30 img-circle" style="margin-right:10px; margin-top:-3px">
				<?php echo e(auth()->user()->name); ?> <span class="caret"></span>
			</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
				<li><a href="<?php echo e(route('user.profile.about')); ?>">About Me</a></li>
				<li><a href="<?php echo e(route('user-profile')); ?>">My Profile</a></li>
				<li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
			</ul>
		</li>
	<?php else: ?>
		<li ><a href="<?php echo e(route('register')); ?>">Register</a></li>
		<li ><a href="<?php echo e(route('login')); ?>">Login</a></li>
	<?php endif; ?>
</ul>